

public class Gui {


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Graph g = new Graph(2);
		Datenelement e = new Datenelement("Mering",0);
		Datenelement f = new Datenelement("Friedberg",1);
		g.knotenHinzufuegen(0,new Knoten(e));
		g.knotenHinzufuegen(1, new Knoten(f));
		g.kanteEinfuegen(e, f, 5);
		g.knotenFuellen();
		System.out.println(g.auslesen("Mering", "Friedberg").getStrecke());
	}
}
