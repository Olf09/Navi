/**
 * 
 */

/**
 * @author deimlf
 *
 */
public class Datenelement {
	//Der Ort den das Datenelement speichert
	private String ort;
	//Die Entfernung zum Anfangsort
	private int entfernung;
	//Der Vorg�ngerort dieses Ortes
	private Datenelement vorgaenger;
	//Die Id des Ortes
	private int id;
	
	/**Konstruktor der Klasse Datenelement
	 * @param ort Der Name des Ortes
	 * @param id Die Id des Ortes
	 */
	public Datenelement(String ort,int id) {
		this.ort=ort;
		this.id=id;
		entfernung = 0;
		vorgaenger=null;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ort;
	}
	/**Gibt die Entfernung zur�ck
	 * @return Die Entfernung
	 */
	public int getEntfernung(){
		return entfernung;
	}
	/**Setzt die Entfernung
	 * @param i Die Entfernung
	 */
	public void setEntfernung(int i) {
		entfernung = i;
	}
	/**Setzt den Vorg�nger
	 * @param v Der Vorg�nger
	 */
	public void setVorgaenger(Datenelement v) {
		vorgaenger = v;
	}
	/**Gibt den Vorg�nger zur�ck
	 * @return Den Vorg�nger
	 */
	public Datenelement getVorgaenger() {
		return vorgaenger;
	}
	/** Gibt die Id zur�ck
	 * @return Die Id
	 */
	public int getId() {
		return id;
	}
}
