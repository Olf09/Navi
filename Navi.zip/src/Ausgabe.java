import java.util.List;
import java.util.ArrayList;

/**
 * 
 */

/**
 * @author deimlf
 *
 */
public class Ausgabe {
	private ArrayList<Datenelement> zwischenziel;
	private int strecke;
	
	public Ausgabe(ArrayList<Datenelement> zwischenziel, int strecke) {
		this.zwischenziel = zwischenziel;
		this.strecke=strecke;
	}
	public int getStrecke() {
		return strecke;
	}
	public Datenelement getZwischenziel(int index) {
		return zwischenziel.get(index);
	}
	public int zwischenzielG() {
		return zwischenziel.size();
	}
}
