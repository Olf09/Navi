import java.util.List;
import java.util.ArrayList;

/**
 * 
 */

/**
 * @author deimlf
 *
 */
public class Ausgabe {
	//Liste der Zwischenziele
	private ArrayList<Datenelement> zwischenziel;
	//Insgesamte Strecke
	private int strecke;
	
	/**Konstruktor der Klasse Ausgabe
	 * @param zwischenziel Liste der Zwischenziele
	 * @param strecke insgesamte Strecke
	 */
	public Ausgabe(ArrayList<Datenelement> zwischenziel, int strecke) {
		this.zwischenziel = zwischenziel;
		this.strecke=strecke;
	}
	/**Gibt das Attribut Strecke zur�ck
	 * @return Attribut Strecke
	 */
	public int getStrecke() {
		return strecke;
	}
	/**Gibt ein bestimmtes Zwischenziel zur�ck
	 * @param index der Liste des gesuchten Zwischenziels
	 * @return
	 */
	public Datenelement getZwischenziel(int index) {
		return zwischenziel.get(index);
	}
	/**Gibt die Gr��e der Liste der Zwischenziele zur�ck
	 * @return Gr��e der Zwischenziele
	 */
	public int zwischenzielG() {
		return zwischenziel.size();
	}
}
