/**
 * 
 */

/**
 * @author deimlf
 *
 */
import java.util.List;
import java.util.ArrayList;
public class Knoten {
	private Datenelement element;
	private ArrayList<Knoten> naechster;
	private boolean besucht;
	
	public Knoten(Datenelement element) {
		this.element=element;
		naechster=new ArrayList<Knoten>();
		
	}
	public Datenelement getElement() {
		return element;
	}
	public void naechsterHinzufuegen(Knoten knoten) {
		naechster.add(knoten);
	}
	public Datenelement suche(Datenelement element) {
		Datenelement data = new Datenelement(null,0);
		if(element.equals(getElement())) {
			data=getElement();
		}
		else {
			besucht = true;
			for(int i=0;i<naechster.size();i++) {
				if(naechster.get(i).getBesucht()==false)
					data = naechster.get(i).suche(element);
			}
		}
		return data;
	}
	public void setBesucht(boolean i) {
		besucht=i;
	}
	public boolean getBesucht() {
		return besucht;
	}
	public Knoten getNaechster(int index) {
		return naechster.get(index);
	}
}

