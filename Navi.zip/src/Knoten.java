/**
 * 
 */

/**
 * @author deimlf
 *
 */
import java.util.List;
import java.util.ArrayList;
public class Knoten {
	//Element des Knotens
	private Datenelement element;
	//Liste mit den Nachbarn des Knotens
	private ArrayList<Knoten> naechster;
	//Gibt an ob der Knoten schon besucht wurde
	private boolean besucht;
	
	/**Knostruktor der Klasse Knoten
	 * @param element Element des Knotens
	 */
	public Knoten(Datenelement element) {
		this.element=element;
		naechster=new ArrayList<Knoten>();
		
	}
	/**Gibt das Element zur�ck
	 * @return Das Element
	 */
	public Datenelement getElement() {
		return element;
	}
	/**F�gt ein Knoten in die Liste der Nachbarn hinzu
	 * @param knoten Der Knoten
	 */
	public void naechsterHinzufuegen(Knoten knoten) {
		naechster.add(knoten);
	}
	/**Sucht ein Datenelement und gibt dieses zur�ck
	 * @param element Das zu suchenede Datenelement
	 * @return Das Datenelement
	 */
	public Datenelement suche(Datenelement element) {
		Datenelement data = new Datenelement(null,0);
		if(element.equals(getElement())) {
			data=getElement();
		}
		else {
			besucht = true;
			for(int i=0;i<naechster.size();i++) {
				if(naechster.get(i).getBesucht()==false)
					data = naechster.get(i).suche(element);
			}
		}
		return data;
	}
	/**Setzt den Besucht Status
	 * @param i Der boolean Wert auf dn besucht gesetzt wird
	 */
	public void setBesucht(boolean i) {
		besucht=i;
	}
	/**Gibt den besucht Status zur�ck
	 * @return Den besucht Status
	 */
	public boolean getBesucht() {
		return besucht;
	}
	/** Gibt einen bestimmten Nachbarknoten zur�ck
	 * @param index Der Index des Nachbarknoten
	 * @return Den Nachbarknoten
	 */
	public Knoten getNaechster(int index) {
		return naechster.get(index);
	}
}

