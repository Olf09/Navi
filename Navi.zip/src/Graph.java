import java.util.List;
import java.util.ArrayList;


/**
 * 
 */

/**
 * @author deimlf
 *
 */
public class Graph{
	//Ein Array mit allen Knoten des Graphen
	private Knoten[] knoten;
	//Die Adjazenzmatrix des Graphen
	private int[][] adjazenzmatrix;
	//Die Anzahl der Knoten des Graphen
	private int n;
	
	/**Konstruktor der Klasse Graph
	 * @param Anzahl der Knoten im Graphen
	 */
	public Graph(int n) {
		this.n =n;
		knoten=new Knoten[n];
		adjazenzmatrix=new int[n][n];
		for(int i =0;i<n;i++) {
			for(int e=0;e<n;e++) {
				adjazenzmatrix[i][e]=999999;
			}
		}
		
	}
	/**F�gt eine Kante in die Adjazenzmatrix ein
	 * @param anfangsort Der Anfangsort der Kante
	 * @param zielort Der Zielort der Kante
	 * @param entfernung Die Entfernung zwischen ANfangsort und Zielort
	 */
	public void kanteEinfuegen(Datenelement anfangsort, Datenelement zielort,int entfernung) {
		for(int i=0;i<n;i++) {
			if(knoten[i].getElement().equals(anfangsort)) {
				for(int e =0;e<n;e++) {
					if(knoten[e].getElement().equals(zielort))
						adjazenzmatrix[i][e]=entfernung;
				}
			}
		}
	}
	/**Setzt die Entfernung von Datenelemente auf die Entfernung zum Anfangsort und gibt die Vorg�nger auf dem k�rzesten Weg zum Anfangsknoten an 
	 * @param anfangsort Der Anfangsort der Route
	 * @param zielort Der Zielort der Route
	 * @return m�gliche Zwischenziele von der Route zwischen ANfangsort und Zielort
	 */
	public List<Datenelement> dijkstra(Datenelement anfangsort, Datenelement zielort) {
		List<Integer> liste1 = new ArrayList<Integer>();
		List<Datenelement> liste2 = new ArrayList<Datenelement>();
		for(int i =0;i<n;i++) {
			liste1.add(i);
		}
		for(int i=0;i<n;i++) {
			knoten[i].getElement().setEntfernung(999999);
			knoten[i].getElement().setVorgaenger(null);
		}
		anfangsort.setEntfernung(0);
		while(!liste2.contains(zielort)) {
			int index = -1;
			int entfernung = 999999;
			for(int i=0;i<liste1.size();i++) {
				if(knoten[liste1.get(i)].getElement().getEntfernung()<entfernung) {
					index=liste1.get(i);
					entfernung=knoten[liste1.get(i)].getElement().getEntfernung();
				}
			}
			System.out.println(index+","+knoten[index].getElement().getEntfernung()+","+knoten[index].getElement().getVorgaenger());
			liste2.add(knoten[index].getElement());
			liste1.remove(new Integer (index));
			
				
					for(int e = 0;e<n;e++) {
						if(liste1.contains(e)) {
							if(knoten[e].getElement().getEntfernung()>knoten[index].getElement().getEntfernung()+adjazenzmatrix[index][e]) {
								knoten[e].getElement().setEntfernung(knoten[index].getElement().getEntfernung()+adjazenzmatrix[index][e]);
								knoten[e].getElement().setVorgaenger(knoten[index].getElement());
							}
						}
					}
				
			
		}
		return liste2;
	}
	/**F�gt einen Favoriten ein
	 * @param favorit Der Favorit
	 */
	public void favoritEinfuegen(Datenelement favorit) {}
	/**F�gt das zu Hause ein
	 * @param zuHause Das zu Hause
	 */
	public void zuHauseEinfuegen(Datenelement zuHause) {}
	/**F�gt eine Route ein die gespeichert werden soll
	 * @param anfangsort Der Anfangsort der Route
	 * @param zielort Der Zielort der Route
	 */
	public void routeEinfuegen(Datenelement anfangsort, Datenelement zielort) {}
	/**Liest die zur�ckgegebene Liste vom dijkstra aus und erstellt dann eine Ausgabe mit den Zwischenzielen und der gesamt Entfernung zwischen Anfangs- und Zielort
	 * @param anfangsort Der Anfangsort
	 * @param zielort Der Zielort
	 * @return Die Ausgabe
	 */
	public Ausgabe auslesen(String anfangsort, String zielort) {	
		Datenelement start = new Datenelement("start",0);
		Datenelement ziel = new Datenelement("ziel",0);
		for(int i=0;i<n;i++) {
			if(knoten[i].getElement().toString().equals(anfangsort))
				start=knoten[i].getElement();
		}
		for(int i=0;i<n;i++) {
			if(knoten[i].getElement().toString().equals(zielort))
				ziel=knoten[i].getElement();
		}
		dijkstra(start,ziel);
		ArrayList<Datenelement> liste = new ArrayList<Datenelement>();
		liste.add(ziel);
		Datenelement e = ziel;
		while(!liste.contains(start)) {
			e=e.getVorgaenger();
			liste.add(e);
		}
		return new Ausgabe(liste,ziel.getEntfernung());	
	}
	/**F�gt einen Knoten in den Graphen hinzu
	 * @param index Der index an dem der Knoten in die Knotenliste eingef�gt wird
	 * @param k Der Knoten
	 */
	public void knotenHinzufuegen(int index, Knoten k) {
		knoten[index]= k;
	}
	/**Gibt einen bestimmten Knoten zur�ck
	 * @param index Der index des Knotens in der Knotenliste
	 * @return Der Knoten
	 */
	public Knoten getKnoten(int index) {
		return knoten[index];
	}
	/**
	 * F�gt bei allen Knoten ihre Nachbarn in deren Nachbarliste hinzu
	 */
	public void knotenFuellen() {
		for(int i=0;i<n;i++) {
			for(int e=0;i<n;i++) {
				if(adjazenzmatrix[i][e] != 0) {
					knoten[i].naechsterHinzufuegen(knoten[e]);
				}
			}
		}
	}

}
